$(document).ready(function () {
  $('#tableDataReimbursement').DataTable();
  $('.dataTables_length').addClass('bs-select');
});

$(document).ready(function () {
  $('#tableDataReimbursementKaryawan').DataTable();
  $('.dataTables_length').addClass('bs-select');
});

$(document).ready(function () {
  $('#tableDataKaryawan').DataTable();
  $('.dataTables_length').addClass('bs-select');
});
