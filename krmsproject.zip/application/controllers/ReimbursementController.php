<?php
/**
 *
 */
class ReimbursementController extends CI_Controller
{

  function __construct()
  {
    $this->load->model('ReimbursementModel');
  }
}


?>
