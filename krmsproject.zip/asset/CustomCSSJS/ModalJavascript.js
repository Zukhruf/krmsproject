var reimbursementModal = new bootstrap.Modal(document.getElementById('reimbursementModal'), {
  reimbursementModal.show()
})
